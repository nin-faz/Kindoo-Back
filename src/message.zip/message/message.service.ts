import { Injectable } from '@nestjs/common';
import { Message } from './entities/message.entity';
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class MessageService {
  private messages: Message[] = [];

  create(content: string, authorId: string): Message {
    const newMessage: Message = {
      id: uuidv4(),
      content,
      createdAt: new Date(),
      authorId,
    };
    this.messages.push(newMessage);
    return newMessage;
  }

  findAll(): Message[] {
    return this.messages;
  }

  findByAuthorId(authorId: string): Message[] {
    return this.messages.filter(msg => msg.authorId === authorId);
  }

  findById(id: string): Message | undefined {
    return this.messages.find(msg => msg.id === id);
  }
}
