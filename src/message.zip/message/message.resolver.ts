import { Resolver, Query, Mutation, Args } from '@nestjs/graphql';
import { MessageService } from './message.service';
import { Message } from './entities/message.entity';

@Resolver(() => Message)
export class MessageResolver {
  constructor(private readonly s_messageService: MessageService) {}

  @Mutation(() => Message)
  sendMessage(
    @Args('content') content: string,
    @Args('authorId') authorId: string,
  ): Message {
    return this.s_messageService.create(content, authorId);
  }

  @Query(() => [Message])
  getAllMessages(): Message[] {
    return this.s_messageService.findAll();
  }

  @Query(() => [Message])
  getMessagesByAuthor(@Args('authorId') authorId: string): Message[] {
    return this.s_messageService.findByAuthorId(authorId);
  }

  @Query(() => Message, { nullable: true })
  getMessageById(@Args('id') id: string): Message | undefined {
    return this.s_messageService.findById(id);
  }
}
